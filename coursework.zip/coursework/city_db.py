import pandas as pd
import os
import logger

logger = logger.get_logger("CityDB")

class CityDatabase:
    def __init__(self, file_path="data/c_cities.xlsx"):
        if not os.path.exists(file_path):
            logger.error(f"Файл {file_path} не найден!")
            self.df = pd.DataFrame()
        else:
            self.df = pd.read_excel(file_path)
            logger.info("База городов успешно загружена.")

    def get_code_by_name(self, city_name: str):
        """Ищет city_code по названию city"""
        # Поиск без учета регистра и лишних пробелов
        result = self.df[self.df['city'].str.lower() == city_name.lower().strip()]
        if not result.empty:
            return str(result.iloc[0]['city_code'])
        return None

db = CityDatabase()