import json
import requests
import config
import logger
from datetime import datetime
from tools import YANDEX_TOOL_SCHEMAS, AVAILABLE_FUNCTIONS

log = logger.get_logger("Agent")

def call_yandex(messages):
    project_id = config.YANDEX_PROJECT_ID.strip()
    url = f"{config.YANDEX_URL.rstrip('/')}/chat/completions"
    payload = {
        "model": f"gpt://{project_id}/yandexgpt/latest",
        "messages": messages,
        "tools": [{"type": "function", "function": s["function"]} for s in YANDEX_TOOL_SCHEMAS],
        "temperature": 0.1
    }
    res = requests.post(url, headers={"Authorization": f"Api-Key {config.YANDEX_KEY}", "x-folder-id": project_id}, json=payload)
    return res.json()['choices'][0]['message']

def run_travel_agent(user_input):
    today = datetime.now().strftime("%Y-%m-%d")
    with open("prompt/instructions.txt", "r", encoding="utf-8") as f:
        system_prompt = f.read()

    messages = [
        {"role": "system", "content": f"{system_prompt}\nСегодня: {today}"},
        {"role": "user", "content": user_input}
    ]

    for _ in range(5):
        msg = call_yandex(messages)
        messages.append(msg)
        if msg.get("tool_calls"):
            for call in msg["tool_calls"]:
                name = call["function"]["name"]
                args = json.loads(call["function"]["arguments"])
                result = AVAILABLE_FUNCTIONS[name](**args)
                messages.append({"role": "tool", "tool_call_id": call["id"], "content": str(result)})
            continue
        return msg.get("content")

if __name__ == "__main__":
    import logger as logger_module 
    logger_module.setup_logging()
    
    print("Транспортный агент запущен. Введите запрос:")
    while True:
        query = input("> ")
        print(run_travel_agent(query))