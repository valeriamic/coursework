import requests
import json
from datetime import datetime
from city_db import db
import config
import logger

logger = logger.get_logger("Tools")

# --- Вспомогательная логика ---

def _get_coords(city_name):
    """Получение координат через Open-Meteo."""
    clean_name = city_name.split(',')[0].strip()
    url = "https://geocoding-api.open-meteo.com/v1/search"
    params = {"name": clean_name, "count": 1, "language": "ru", "format": "json"}
    try:
        res = requests.get(url, params=params, timeout=5).json()
        if "results" in res:
            result = res["results"][0]
            return result["latitude"], result["longitude"], result.get("timezone", "UTC")
    except Exception as e:
        logger.error(f"Ошибка геокодинга ({clean_name}): {e}")
    return None, None, "UTC"

# --- Инструменты для YandexGPT ---

def get_city_code(city_name: str) -> str:
    """Ищет код города (city_code) в Excel-таблице."""
    logger.info(f"Инструмент: поиск кода для города {city_name}")
    code = db.get_code_by_name(city_name)
    if code:
        return code
    return f"Город '{city_name}' не найден в локальной базе Excel."

def get_trip_data(from_city: str, to_code: str, date_str: str) -> str:
    """
    Собирает данные о рейсах и погоде в пункте отправления.
    Не делает выводов, только возвращает факты для анализа моделью.
    """
    logger.info(f"Инструмент: сбор данных для поездки из {from_city} на {date_str}")
    
    # 1. Код города отправления из Excel
    from_code = db.get_code_by_name(from_city)
    if not from_code:
        return f"Ошибка: Не найден код Яндекса для города отправления {from_city}"

    # 2. Координаты для погоды
    lat, lon, tz = _get_coords(from_city)
    
    # 3. Запрос рейсов через API Яндекс.Расписаний
    yandex_url = "https://api.rasp.yandex-net.ru/v3.0/search/"
    yandex_params = {
        "from": from_code,
        "to": to_code,
        "date": date_str,
        "apikey": config.YANDEX_RASP_API_KEY,
        "lang": "ru_RU",
        "limit": 30
    }
    
    try:
        resp = requests.get(yandex_url, params=yandex_params, timeout=10)
        data = resp.json()
        segments = data.get('segments', [])
        
        if not segments:
            return f"Инфо: Рейсов из {from_city} на {date_str} не найдено."

        output = []
        for i, seg in enumerate(segments, 1):
            title = seg['thread']['title']
            dep_time = seg['departure']
            t_type = seg['thread'].get('transport_type')
            
            # 4. Сбор погоды на момент отправления
            weather_data = "Данные о погоде недоступны"
            if lat:
                w_url = "https://api.open-meteo.com/v1/forecast"
                # Приводим время к формату Open-Meteo (округляем до часа)
                dt = datetime.fromisoformat(dep_time).replace(minute=0, second=0, microsecond=0)
                target_hour = dt.strftime("%Y-%m-%dT%H:%M")
                
                w_params = {
                    "latitude": lat, "longitude": lon, "timezone": tz,
                    "hourly": "temperature_2m,precipitation,windspeed_10m,visibility",
                    "windspeed_unit": "ms"
                }
                
                w_res = requests.get(w_url, params=w_params).json()
                times = w_res.get('hourly', {}).get('time', [])
                
                if target_hour in times:
                    idx = times.index(target_hour)
                    h = w_res['hourly']
                    weather_data = (
                        f"Температура: {h['temperature_2m'][idx]}°C, "
                        f"Ветер: {h['windspeed_10m'][idx]} м/с, "
                        f"Осадки: {h['precipitation'][idx]} мм, "
                        f"Видимость: {h['visibility'][idx]} м"
                    )

            output.append(
                f"РЕЙС №{i}:\n"
                f"Маршрут: {title}\n"
                f"Тип транспорта: {t_type}\n"
                f"Время старта: {dep_time}\n"
                f"Погода в пункте старта: {weather_data}"
            )

        return "\n\n".join(output)

    except Exception as e:
        return f"Ошибка при сборе данных: {str(e)}"

# --- Регистрация функций ---

AVAILABLE_FUNCTIONS = {
    "get_city_code": get_city_code,
    "get_trip_data": get_trip_data
}

YANDEX_TOOL_SCHEMAS = [
    {
        "function": {
            "name": "get_city_code",
            "description": "Ищет код города в Excel-файле по названию.",
            "parameters": {
                "type": "object",
                "properties": {"city_name": {"type": "string"}},
                "required": ["city_name"]
            }
        }
    },
    {
        "function": {
            "name": "get_trip_data",
            "description": "Получает список рейсов и подробную погоду на время каждого рейса.",
            "parameters": {
                "type": "object",
                "properties": {
                    "from_city": {"type": "string", "description": "Название города отправления"},
                    "to_code": {"type": "string", "description": "Код города прибытия"},
                    "date_str": {"type": "string", "description": "ГГГГ-ММ-ДД"}
                },
                "required": ["from_city", "to_code", "date_str"]
            }
        }
    }
]