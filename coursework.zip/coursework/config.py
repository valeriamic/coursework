import os
import logger
from dotenv import load_dotenv

logger = logger.get_logger("Config")
load_dotenv()

# Ключи Yandex Cloud
YANDEX_KEY = os.getenv("YANDEX_KEY")
YANDEX_PROJECT_ID = os.getenv("YANDEX_PROJECT_ID")
YANDEX_RASP_API_KEY = os.getenv("YANDEX_RASP_API_KEY")

# URL из ваших данных (Completion API v1)
YANDEX_URL = "https://ai.api.cloud.yandex.net/v1"

# Формируем URI модели согласно вашим данным
if YANDEX_PROJECT_ID:
    YANDEX_MODEL_URI = f"gpt://{YANDEX_PROJECT_ID}/yandexgpt/latest"
else:
    YANDEX_MODEL_URI = None

# Пути к ресурсам
CITY_DB_PATH = "data/c_cities.xlsx"
SYSTEM_PROMPT_PATH = "prompt/instructions.txt"

def check_config():
    if not YANDEX_KEY or not YANDEX_PROJECT_ID:
        logger.error("Проверьте ключи YANDEX_KEY и YANDEX_PROJECT_ID в .env")
        return False
    if not os.path.exists(CITY_DB_PATH):
        logger.error(f"Файл не найден: {CITY_DB_PATH}")
        return False
    return True